const request = require('request');

exports.handler = (event, context, callback) => {
	request({
		method: 'POST',
		uri: 'https://07hpttbwpc.execute-api.us-east-1.amazonaws.com/prod/chatbot',
		headers: { 'content-type': 'application/json' },
		body: event,
		json: true
	}, function(err, data) {
		if (!!err) {
			console.error(err, data)
		}
		else {
			callback(null, data.body);
		}
	})
};